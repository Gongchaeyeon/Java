
import java.util.*;

// An exploration of basic input and output.
class BasicIO {

	// Reads and processes string input.
	public static void main(String[] args) {
		Scanner stdin = new Scanner(System.in);
		// get first input
		System.out.print("Enter your name: ");
		String name = stdin.nextLine();
		// display output on console
		System.out.print("Enter your Age: ");
		Integer year = stdin.nextInt();
		System.out.print("Enter your height: ");
		Integer height = stdin.nextInt();
		
		System.out.println("your name is " + name + " " + year);
		System.out.println(year*365);
		System.out.println("2005�� 09�� 06�� ���� "+name+"("+year+")�� Ű�� "+height+"cm �Դϴ�." );
	} // method main
} // class BASIC_IO